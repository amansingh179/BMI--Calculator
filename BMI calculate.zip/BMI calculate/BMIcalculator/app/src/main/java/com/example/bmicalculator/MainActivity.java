package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText editkg,editcm;
        TextView editresult,editbmi;
        Button editcal,editres;

        editkg=(EditText)findViewById(R.id.editkg);
        editcm=(EditText)findViewById(R.id.editcm);

        editresult=(TextView)findViewById(R.id.editresult);
        editbmi=(TextView) findViewById(R.id.editbmi);

        editcal=(Button)findViewById(R.id.editcal);
        editres=(Button)findViewById(R.id.editres);

        editcal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strkg= editkg.getText().toString();
                String strcm=editcm.getText().toString();

                if(strkg.equals("")){
                    editkg.setError("Please Enter Your Weight");
                    editkg.requestFocus();
                    return;
                }
                if(strcm.equals("")){
                    editcm.setError("Please Enter Your Height");
                    editcm.requestFocus();
                    return;
                }

                float weight=Float.parseFloat(strkg);
                float height=Float.parseFloat(strcm)/100 ;

                float bmivalue = BMIcalculate(weight,height);

                editresult.setText(interpreteBMI(bmivalue));
                editbmi.setText("BMI= "+bmivalue);
            }
        });
        editres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editkg.setText("");
                editcm.setText("");
                editkg.setText("");
                editcm.setText("");
                editresult.setText("RESULT");
                editbmi.setText("BMI = ?");
            }
        });



    }

    public float BMIcalculate(float weight,float height){
            return weight / (height*height);
    }
    public String interpreteBMI(float bmivalue){
        if(bmivalue <18.5){
            return "Underweight";
        }
        else if(bmivalue<25){
            return "Normal";
        }
        else if(bmivalue<30){
            return "Overweight";
        }
        else
            return "Obese";
    }
}